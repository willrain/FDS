/**
 * @file
 * README file for Telegram Drupal module.
 */

Send and receive messages with Drupal using Telegram protocol.
This module uses Telegram messenger CLI

See https://telegram.org/
See https://github.com/vysheng/tg

This is under active development.

*******************************************************
WARNING: Some components must be downloaded and compiled.
WARNING: If you cannot compile them, don't use it yet.
*******************************************************
Requires X Autoload module
https://drupal.org/project/xautoload

Do read INSTALL.txt

Developers:
- Jose Manuel Guerrero, http://jmanuelguerrero.com
- Jose Reyero, http://reyero.net
